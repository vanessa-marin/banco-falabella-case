# Banco Falabella – Product Case (English)

This repository contains the full case in English and Spanish.
