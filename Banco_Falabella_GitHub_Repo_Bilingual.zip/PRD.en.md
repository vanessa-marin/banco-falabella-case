# PRD – Banco Falabella (EN)
Requirements in English.