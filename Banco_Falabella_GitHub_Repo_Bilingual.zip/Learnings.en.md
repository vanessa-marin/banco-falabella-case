# Learnings – Banco Falabella (EN)
Key learnings in English.