# Metrics – Banco Falabella (EN)
Key metrics in English.