# Case Summary – Banco Falabella (ES)
Resumen en español.