# Case Summary – Banco Falabella (EN)
Executive summary in English.